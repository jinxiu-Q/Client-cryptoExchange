import 'package:coin_exchange/AppNavigation/app_navigation.dart';
import 'package:coin_exchange/Auth/sign_in/sign_in_ui.dart';
import 'package:coin_exchange/Auth/sign_up/sign_up.dart';
import 'package:coin_exchange/Auth/verification/verification_ui.dart';
import 'package:coin_exchange/BottomBarItems/Home/buy.dart';
import 'package:coin_exchange/BottomBarItems/Home/currency_detail.dart';
import 'package:coin_exchange/BottomBarItems/Home/sell.dart';
import 'package:coin_exchange/BottomBarItems/Profile/bank_details.dart';
import 'package:coin_exchange/BottomBarItems/Profile/help_and_support.dart';
import 'package:coin_exchange/BottomBarItems/Profile/history.dart';
import 'package:coin_exchange/BottomBarItems/Profile/privacy_policy.dart';
import 'package:coin_exchange/BottomBarItems/Profile/user_verification.dart';
import 'package:coin_exchange/Locale/language_ui.dart';
import 'package:flutter/material.dart';

class PageRoutes {
  static const String signIn = "signIn";
  static const String signUp = "signUp";
  static const String verification = "verification";
  static const String appNavigation = "appNavigation";
  static const String bankDetails = "bankDetails";
  static const String helpAndSupport = "helpAndSupport";
  static const String history = "history";
  static const String privacyPolicy = "privacyPolicy";
  static const String userVerification = "userVerification";
  static const String language = "language";
  static const String currencyDetail = "currencyDetail";
  static const String buy = "buy";
  static const String sell = "sell";

  Map<String, WidgetBuilder> routes() {
    return {
      signIn: (context) => SignIn(),
      signUp: (context) => SignUp(),
      verification: (context) => Verification(),
      appNavigation: (context) => AppNavigation(),
      bankDetails: (context) => BankDetails(),
      helpAndSupport: (context) => HelpAndSupport(),
      history: (context) => History(),
      privacyPolicy: (context) => PrivacyPolicy(),
      userVerification: (context) => UserVerification(),
      language: (context) => LanguageUI(),
      currencyDetail: (context) => CurrencyDetail(),
      buy: (context) => Buy(),
      sell: (context) => Sell(),
    };
  }
}
