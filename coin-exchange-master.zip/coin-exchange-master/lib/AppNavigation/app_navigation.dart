import 'package:coin_exchange/BottomBarItems/Home/home.dart';
import 'package:coin_exchange/BottomBarItems/Market/market.dart';
import 'package:coin_exchange/BottomBarItems/Portfolio/portfolio.dart';
import 'package:coin_exchange/BottomBarItems/Profile/profile.dart';
import 'package:flutter/material.dart';
import 'package:coin_exchange/Locale/locales.dart';

class AppNavigation extends StatefulWidget {
  @override
  _AppNavigationState createState() => _AppNavigationState();
}

class _AppNavigationState extends State<AppNavigation> {
  int _currentIndex = 0;

  final List<Widget> _children = [
    Home(),
    Portfolio(),
    Market(),
    Profile(),
  ];

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    final List<BottomNavigationBarItem> _items = [
      BottomNavigationBarItem(
        icon: Icon(
          Icons.home,
        ),
        label: getTranslationOf('home'),
      ),
      BottomNavigationBarItem(
        icon: Icon(
          Icons.timeline,
        ),
        label: getTranslationOf('portfolio'),
      ),
      BottomNavigationBarItem(
        icon: Icon(
          Icons.trending_up,
        ),
        label: getTranslationOf('market'),
      ),
      BottomNavigationBarItem(
        icon: Icon(
          Icons.person_outline,
        ),
        label: getTranslationOf('profile'),
      ),
    ];
    return Scaffold(
      body: _children[_currentIndex],
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.only(
            topRight: Radius.circular(30), topLeft: Radius.circular(30)),
        child: Theme(
          data: Theme.of(context).copyWith(
            canvasColor: theme.backgroundColor,
            primaryColor: theme.primaryColor,
          ),
          child: BottomNavigationBar(
            showUnselectedLabels: true,
            items: _items,
            currentIndex: _currentIndex,
            selectedItemColor: Theme.of(context).primaryColor,
            unselectedItemColor: theme.hintColor,
            onTap: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
          ),
        ),
      ),
    );
  }
}
