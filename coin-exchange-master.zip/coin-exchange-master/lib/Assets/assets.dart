class Assets {
  static const String bitcoin = 'assets/Currency/ic_Bitcoin.png';
  static const String ethereum = 'assets/Currency/ic_ethereum.png';
  static const String theter = 'assets/Currency/ic_theter.png';
  static const String logo = 'assets/Logo.png';
  static const String signInImage = 'assets/signIn.png';
  static const String homeImage = 'assets/Home/Click to edit.png';
  static const String graph = 'assets/Home/Graph.png';
  static const String profile = 'assets/Home/Profile.png';
  static const String portfolio = 'assets/portfolio.png';
  static const String portfolioGraph = 'assets/portfolio_graph.png';
}
