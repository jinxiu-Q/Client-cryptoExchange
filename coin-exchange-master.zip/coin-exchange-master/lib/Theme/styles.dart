import 'package:flutter/material.dart';

final ThemeData appTheme = ThemeData(
  fontFamily: 'Poppins',
  backgroundColor: Color(0xff2D2D2D),
  scaffoldBackgroundColor: Color(0xff212121),
  primaryColor: Color(0xff38B8BD),
  hintColor: Color(0xff9E9E9E),
  appBarTheme: AppBarTheme(
    color: Colors.transparent,
    elevation: 0,
    iconTheme: IconThemeData(
      color: Colors.white,
    ),
  ),
  iconTheme: IconThemeData(
    color: Colors.white,
  ),
  textTheme: TextTheme(
          button: TextStyle(
              color: Colors.white,
              fontSize: 18,
              letterSpacing: 2,
              fontWeight: FontWeight.w700),
          bodyText1:
              TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
          headline2: TextStyle(),
          headline3: TextStyle(),
          caption: TextStyle(
            color: Colors.white,
          ),
          headline1: TextStyle(),
          subtitle1: TextStyle(
            color: Colors.white,
          ),
          headline6: TextStyle(color: Color(0xff9E9E9E), fontSize: 14),
          bodyText2: TextStyle(
            color: Colors.black,
          ),
          subtitle2: TextStyle(
            color: Color(0xff9E9E9E),
            fontSize: 12,
          ),
          headline5: TextStyle(
              color: Colors.white, fontWeight: FontWeight.w500, fontSize: 20))
      .apply(bodyColor: Colors.white),
);

/// NAME         SIZE  WEIGHT  SPACING
/// headline1    96.0  light   -1.5
/// headline2    60.0  light   -0.5
/// headline3    48.0  regular  0.0
/// headline4    34.0  regular  0.25
/// headline5    24.0  regular  0.0
/// headline6    20.0  medium   0.15
/// subtitle1    16.0  regular  0.15
/// subtitle2    14.0  medium   0.1
/// body1        16.0  regular  0.5   (bodyText1)
/// body2        14.0  regular  0.25  (bodyText2)
/// button       14.0  medium   1.25
/// caption      12.0  regular  0.4
/// overline     10.0  regular  1.5
