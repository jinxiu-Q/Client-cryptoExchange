import 'package:flutter/material.dart';

Color whiteTextColor = Colors.white;
Color blackTextColor = Colors.black;
Color iconColor = Colors.white;
Color darkBgColor = Color(0xffA2A2A2);
Color greenColor = Colors.green;
Color redColor = Colors.red;
Color darkButtonColor = Color(0xff2C2C2C);

Gradient cardGradient = LinearGradient(
  colors: [
    Color(0xff2C2C2C),
    Color(0xff3E3E3E),
  ],
  begin: Alignment.centerLeft,
  end: Alignment.centerRight,
);
Gradient blueGradient = LinearGradient(
  colors: [
    Color(0xff2EDB99),
    Color(0xff38B7BE),
  ],
  begin: Alignment.centerLeft,
  end: Alignment.centerRight,
);
Gradient orangeGradient = LinearGradient(
  colors: [
    Color(0xffFE8C00),
    Color(0xffF83A00),
  ],
  begin: Alignment.centerLeft,
  end: Alignment.centerRight,
);
