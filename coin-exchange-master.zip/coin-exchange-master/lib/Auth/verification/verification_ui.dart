import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:coin_exchange/Assets/assets.dart';
import 'package:coin_exchange/Components/custom_button.dart';
import 'package:coin_exchange/Components/entry_field_for_verification.dart';
import 'package:coin_exchange/Routes/routes.dart';
import 'package:coin_exchange/Theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:coin_exchange/Locale/locales.dart';

class Verification extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    return Scaffold(
      body: FadedSlideAnimation(
        ListView(
          children: [
            Image.asset(
              Assets.signInImage,
              scale: 2.5,
            ),
            Text(
              context.getTranslationOf('awesome_thanks')!,
              style: theme.textTheme.headline5,
              textAlign: TextAlign.center,
            ),
            RichText(
              textAlign: TextAlign.center,
              text: TextSpan(
                  text: context.getTranslationOf('please_enter'),
                  style: theme.textTheme.subtitle2,
                  children: [
                    TextSpan(
                      text: '9876543210',
                      style: theme.textTheme.subtitle2!.copyWith(
                        fontWeight: FontWeight.bold,
                        color: whiteTextColor,
                      ),
                    ),
                    TextSpan(
                      text: '  ' + context.getTranslationOf('edit')!,
                      style: theme.textTheme.subtitle2!.copyWith(
                        fontWeight: FontWeight.bold,
                        color: theme.primaryColor,
                      ),
                    ),
                  ]),
            ),
            SizedBox(
              height: 40,
            ),
            Row(
              children: [
                SizedBox(
                  width: 10,
                ),
                EntryFieldForVerification(
                  initialValue: '8',
                ),
                EntryFieldForVerification(
                  initialValue: '2',
                ),
                EntryFieldForVerification(),
                EntryFieldForVerification(),
                EntryFieldForVerification(),
                EntryFieldForVerification(),
                SizedBox(
                  width: 10,
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            CustomButton(
              text: context.getTranslationOf('verify_number'),
              onTap: () {
                Navigator.pushNamed(context, PageRoutes.appNavigation);
              },
            ),
            Text(
              context.getTranslationOf('send_again')!,
              style: theme.textTheme.subtitle2!.copyWith(
                fontWeight: FontWeight.bold,
                color: theme.primaryColor,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        slideCurve: Curves.linearToEaseOut,
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
      ),
    );
  }
}
