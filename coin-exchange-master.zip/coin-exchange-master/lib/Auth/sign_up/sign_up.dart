import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:coin_exchange/Components/custom_button.dart';
import 'package:coin_exchange/Components/entry_field.dart';
import 'package:coin_exchange/Routes/routes.dart';
import 'package:coin_exchange/Theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:coin_exchange/Locale/locales.dart';

class SignUp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          context.getTranslationOf('create_account')!,
          style: theme.textTheme.headline5!.copyWith(
            fontSize: 18,
          ),
        ),
        centerTitle: true,
      ),
      body: FadedSlideAnimation(
        ListView(
          children: [
            Padding(
              padding: const EdgeInsets.only(
                  bottom: 8.0, left: 16, right: 16, top: 20),
              child: Text(
                context.getTranslationOf('full_name')!,
                style: theme.textTheme.subtitle2!.copyWith(color: darkBgColor),
              ),
            ),
            EntryField(
              color: theme.backgroundColor,
            ),
            Padding(
              padding: const EdgeInsets.only(
                  bottom: 8.0, left: 16, right: 16, top: 20),
              child: Text(
                context.getTranslationOf('email_address')!,
                style: theme.textTheme.subtitle2!.copyWith(color: darkBgColor),
              ),
            ),
            EntryField(
              color: theme.backgroundColor,
            ),
            Padding(
              padding: const EdgeInsets.only(
                  bottom: 8.0, left: 16, right: 16, top: 20),
              child: Text(
                context.getTranslationOf('phone_number')!,
                style: theme.textTheme.subtitle2!.copyWith(color: darkBgColor),
              ),
            ),
            EntryField(
              color: theme.backgroundColor,
            ),
            SizedBox(
              height: 100,
            ),
            CustomButton(
              text: context.getTranslationOf('next'),
              onTap: () {
                Navigator.pushNamed(context, PageRoutes.verification);
              },
            )
          ],
        ),
        slideCurve: Curves.linearToEaseOut,
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
      ),
    );
  }
}
