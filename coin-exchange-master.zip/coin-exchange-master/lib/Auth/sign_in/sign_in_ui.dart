import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:coin_exchange/Assets/assets.dart';
import 'package:coin_exchange/Components/custom_button.dart';
import 'package:coin_exchange/Components/entry_field.dart';
import 'package:coin_exchange/Routes/routes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:coin_exchange/Locale/locales.dart';

class SignIn extends StatefulWidget {
  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    return Scaffold(
      body: FadedSlideAnimation(
        ListView(
          children: [
            Image.asset(
              Assets.signInImage,
              scale: 2.5,
            ),
            Text(
              context.getTranslationOf('lets_get_started')!,
              style: theme.textTheme.headline5,
              textAlign: TextAlign.center,
            ),
            Text(
              context.getTranslationOf('we_will_send')!,
              style: theme.textTheme.subtitle2,
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 40,
            ),
            EntryField(
              initialValue: '(+1) 9876543210',
            ),
            CustomButton(
              text: context.getTranslationOf('next'),
              onTap: () {
                Navigator.pushNamed(context, PageRoutes.signUp);
              },
            ),
          ],
        ),
        slideCurve: Curves.linearToEaseOut,
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
      ),
    );
  }
}
