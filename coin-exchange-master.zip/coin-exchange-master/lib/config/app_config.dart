import 'package:coin_exchange/Locale/Languages/arabic.dart';
import 'package:coin_exchange/Locale/Languages/english.dart';
import 'package:coin_exchange/Locale/Languages/french.dart';
import 'package:coin_exchange/Locale/Languages/indonesian.dart';
import 'package:coin_exchange/Locale/Languages/italian.dart';
import 'package:coin_exchange/Locale/Languages/portuguese.dart';
import 'package:coin_exchange/Locale/Languages/spanish.dart';
import 'package:coin_exchange/Locale/Languages/swahili.dart';
import 'package:coin_exchange/Locale/Languages/turkish.dart';

class AppConfig {
  static final String appName = 'Pharmazone Vendor';
  static final String packageName = 'com.flutter.pharmazone_vendor';
  static final String languageDefault = "en";
  static final Map<String, AppLanguage> languagesSupported = {
    'en': AppLanguage("English", english()),
    'ar': AppLanguage("عربى", arabic()),
    'pt': AppLanguage("Portugal", portuguese()),
    'fr': AppLanguage("Français", french()),
    'id': AppLanguage("Bahasa Indonesia", indonesian()),
    'es': AppLanguage("Español", spanish()),
    'it': AppLanguage("italiano", italian()),
    'tr': AppLanguage("Türk", turkish()),
    'sw': AppLanguage("Kiswahili", swahili()),
  };
  static final bool isDemoMode = true;
}

class AppLanguage {
  final String name;
  final Map<String, String> values;
  AppLanguage(this.name, this.values);
}
