import 'package:flutter/material.dart';

class EntryField2 extends StatefulWidget {
  final String? hintText;
  final String? suffixText;
  final Color? hintColor;
  final String? label;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final EdgeInsetsGeometry? padding;
  final TextStyle? hintStyle;
  final num? width;
  final EdgeInsets? labelFieldPadding;
  final String? initialValue;
  EntryField2(
      {this.hintText,
      this.suffixText,
      this.hintColor,
      this.label,
      this.prefixIcon,
      this.padding,
      this.suffixIcon,
      this.hintStyle,
      this.width,
      this.labelFieldPadding,
      this.initialValue});

  @override
  _EntryField2State createState() => _EntryField2State();
}

class _EntryField2State extends State<EntryField2> {
  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    return Padding(
      padding: widget.padding ?? EdgeInsets.all(14.0),
      child: SizedBox(
        width: widget.width as double? ?? MediaQuery.of(context).size.width * 0.9,
        height: 70,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            widget.label != null
                ? Text(
                    widget.label!,
                    style: theme.textTheme.subtitle2!
                        .copyWith(color: theme.hintColor, fontSize: 10),
                  )
                : SizedBox.shrink(),
            TextFormField(
              style: theme.textTheme.caption!.copyWith(
                fontSize: 15,
              ),
              initialValue: widget.initialValue,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                contentPadding: widget.labelFieldPadding,
                prefixIcon: widget.prefixIcon,
                hintText: widget.hintText,
                hintStyle: widget.hintStyle ??
                    theme.textTheme.subtitle2!.copyWith(
                      fontSize: 16,
                    ),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: theme.hintColor),
                ),
                suffixIcon: widget.suffixIcon ??
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 0.0),
                      child: Text(
                        widget.suffixText ?? '',
                        style: theme.textTheme.subtitle2!
                            .copyWith(color: theme.primaryColor, fontSize: 15),
                      ),
                    ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
