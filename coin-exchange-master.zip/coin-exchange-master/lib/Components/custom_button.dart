import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:coin_exchange/Theme/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  const CustomButton({
    this.text,
    this.onTap,
    this.margin,
    this.icon,
    this.gradient,
    this.color,
  });
  final String? text;
  final Function? onTap;
  final EdgeInsets? margin;
  final Icon? icon;
  final Gradient? gradient;
  final Color? color;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap as void Function()?,
      child: FadedScaleAnimation(
        Container(
          margin: margin ?? EdgeInsets.all(16),
          padding: EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              gradient: gradient ?? blueGradient,
              color: color ?? Theme.of(context).primaryColor,
              borderRadius: BorderRadius.circular(12)),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              icon ?? SizedBox.shrink(),
              icon != null
                  ? SizedBox(
                      width: 4,
                    )
                  : SizedBox.shrink(),
              Text(text!),
            ],
          ),
        ),
      ),
    );
  }
}
