import 'package:coin_exchange/Theme/colors.dart';
import 'package:flutter/material.dart';

class EntryField extends StatelessWidget {
  final String? initialValue;
  final Color? color;

  const EntryField({this.initialValue, this.color});

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 24),
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 0),
      decoration: BoxDecoration(
        color: color ?? whiteTextColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextFormField(
        initialValue: initialValue ?? '',
        style: theme.textTheme.bodyText2!.copyWith(
          color: blackTextColor,
        ),
        decoration: InputDecoration(
            focusedBorder: UnderlineInputBorder(borderSide: BorderSide.none)),
      ),
    );
  }
}
