import 'package:flutter/material.dart';

class EntryFieldForVerification extends StatelessWidget {
  final String? initialValue;

  const EntryFieldForVerification({this.initialValue});

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 8),
        child: TextFormField(
          textAlign: TextAlign.center,
          keyboardType: TextInputType.phone,
          initialValue: initialValue,
          style: theme.textTheme.subtitle1,
          decoration: InputDecoration(
              enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Theme.of(context).hintColor),
          )),
        ),
      ),
    );
  }
}
