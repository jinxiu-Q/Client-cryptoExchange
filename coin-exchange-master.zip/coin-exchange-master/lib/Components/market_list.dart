import 'package:coin_exchange/Components/percentage_widget.dart';
import 'package:coin_exchange/Routes/routes.dart';
import 'package:flutter/material.dart';

import '../Assets/assets.dart';
import '../Theme/colors.dart';
import 'package:coin_exchange/Locale/locales.dart';

class Currencies {
  final String image;
  final String? title;
  final String? subtitle;
  final String value;
  final bool isGreen;

  Currencies(this.image, this.title, this.subtitle, this.value, this.isGreen);
}

class MarketList extends StatelessWidget {
  final int count;
  MarketList(this.count);
  @override
  Widget build(BuildContext context) {
    List<Currencies> currencies = [
      Currencies(Assets.bitcoin, context.getTranslationOf('bitcoin'),
          context.getTranslationOf('btc'), 'INR 0.001.321.514', true),
      Currencies(Assets.ethereum, context.getTranslationOf('etherium'),
          context.getTranslationOf('eth'), 'INR 5,654,000', true),
      Currencies(Assets.theter, context.getTranslationOf('theter'),
          context.getTranslationOf('usdt'), 'INR 16,876.215', false),
      Currencies(Assets.bitcoin, context.getTranslationOf('bitcoin'),
          context.getTranslationOf('btc'), 'INR 0.001.321.514', true),
      Currencies(Assets.ethereum, context.getTranslationOf('etherium'),
          context.getTranslationOf('eth'), 'INR 5,654,000', true),
      Currencies(Assets.theter, context.getTranslationOf('theter'),
          context.getTranslationOf('usdt'), 'INR 16,876.215', false),
      Currencies(Assets.bitcoin, context.getTranslationOf('bitcoin'),
          context.getTranslationOf('btc'), 'INR 0.001.321.514', true),
      Currencies(Assets.ethereum, context.getTranslationOf('etherium'),
          context.getTranslationOf('eth'), 'INR 5,654,000', true),
      Currencies(Assets.theter, context.getTranslationOf('theter'),
          context.getTranslationOf('usdt'), 'INR 16,876.215', false),
      Currencies(Assets.bitcoin, context.getTranslationOf('bitcoin'),
          context.getTranslationOf('btc'), 'INR 0.001.321.514', true),
      Currencies(Assets.ethereum, context.getTranslationOf('etherium'),
          context.getTranslationOf('eth'), 'INR 5,654,000', true),
      Currencies(Assets.theter, context.getTranslationOf('theter'),
          context.getTranslationOf('usdt'), 'INR 16,876.215', false),
    ];
    return ListView.builder(
        physics: NeverScrollableScrollPhysics(),
        itemCount: count,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return Column(
            children: [
              ListTile(
                onTap: () {
                  Navigator.pushNamed(context, PageRoutes.currencyDetail);
                },
                contentPadding: EdgeInsets.symmetric(vertical: 2),
                leading: CircleAvatar(
                    radius: 24,
                    backgroundColor: Colors.white.withOpacity(0.05),
                    child: Image.asset(
                      currencies[index].image,
                      height: 28,
                    )),
                title: Row(
                  children: [
                    Text(currencies[index].title!),
                    Spacer(),
                    Text(currencies[index].value)
                  ],
                ),
                subtitle: Row(
                  children: [
                    Text(
                      currencies[index].subtitle!,
                      style: Theme.of(context)
                          .textTheme
                          .subtitle2!
                          .copyWith(fontSize: 10, color: darkBgColor),
                    ),
                    Spacer(),
                    PercentageWidget(currencies[index].isGreen),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                height: 1,
                decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                  Colors.transparent,
                  darkBgColor,
                  Colors.transparent
                ])),
              ),
            ],
          );
        });
  }
}
