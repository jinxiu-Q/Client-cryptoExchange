import 'package:flutter/material.dart';
import 'package:coin_exchange/Theme/colors.dart';

class PercentageWidget extends StatelessWidget {
  final bool isGreen;
  PercentageWidget(this.isGreen);
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 34,
      padding: EdgeInsets.symmetric(horizontal: 2, vertical: 1),
      margin: EdgeInsets.symmetric(horizontal: 6),
      color: isGreen
          ? Theme.of(context).primaryColor.withOpacity(0.3)
          : redColor.withOpacity(0.3),
      child: Text(
        '+10.06%',
        style: Theme.of(context)
            .textTheme
            .bodyText1!
            .copyWith(fontSize: 7, color: isGreen ? greenColor : redColor),
      ),
    );
  }
}
